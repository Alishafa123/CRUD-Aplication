const express=require("express");
const bodyparse=require("body-parser");
const mysql=require("mysql");
const multer=require("multer");
const app=express();
const encoded=bodyparse.urlencoded();

const upload=multer({


storage:multer.diskStorage({
    destination:function(req,file,cb)
    {
        cb(null,"uploads");
    },
    filename:function(req,file,cb)
    {
    cb(null,file.filename+"-"+Date.now()+".jpg")
    }
})



})

let name="";
app.set("view engine","ejs");
const con=mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'',
    database:'fakedatabase'
}
)
con.connect((error)=>{
    if(error){
        console.log("Error");
    }
    else{
        console.log("Database has been connected");
    }
})

//res.sendFile(__dirname+"/menu.html");
// app.get("/",(req,res)=>{
// //res.sendFile(__dirname+"/login.html");
// res.sendFile(__dirname+"/registration.html");
// })

app.get("/",(req,res)=>{
   res.sendFile(__dirname+"/login.html");
   //res.sendFile(__dirname+"/menu.html");
})
app.get("/menu",(req,res)=>{
    //res.sendFile(__dirname+"/login.html");
    res.sendFile(__dirname+"/menu.html");
 })

app.get("/registration",(req,res)=>{
    res.sendFile(__dirname+"/Registration.html");
})

app.post("/registration",encoded,(req,res)=>{
//res.sendFile(__dirname+"/Registration.html");
let username=req.body.username;
let email=req.body.email;
let password=req.body.password;
console.log(username);
console.log(email);
//[username,email,password],

let query="INSERT INTO userdata(name,email,pass) VALUES('"+username+"','"+email+"','"+password+"');"
console.log(query);
con.query('INSERT INTO userdata(name,email,pass) VALUES(?,?,?)',[username,email,password],(error,result)=>{
    if(error){
        console.log("Error");
       res.redirect("/welcome");
    }
    else{
        console.log("Data inserted");
        res.redirect("/");
    }
}) 
})


app.post("/updatestudent",encoded,(req,res)=>{
    //res.sendFile(__dirname+"/Registration.html");
    let name_=req.body.name_;
    let username=req.body.username;
    let email=req.body.email;
    let password=req.body.password;
    let phone=req.body.phone;
    let age=req.body.age;
    let qualification=req.body.qualification;

let query="update students set name = '"+name_+"',username ='"+username+"',email='"+email+"',password='"+password+"',phonenumber='"+phone+"',age='"+age+"',qualification='"+qualification +"' where name ='"+name+"'";
    //[username,email,password],
console.log(query);

    con.query(query,(error,result)=>{
        if(error){
            console.log("Error");
           res.redirect("/welcome");
        }
        else{
            console.log("Data Updateed");
            res.redirect("/menu");
        }
    }) 
    })

    app.get("/delete",(req,res)=>{
        res.sendFile(__dirname+"/delete.html");
    })
    

    app.post("/delete_record",encoded,(req,res)=>{
        //res.sendFile(__dirname+"/Registration.html");
        let name_=req.body.name;

    let query="Delete from students where name ='"+name_+"';";
        //[username,email,password],
    
    
        con.query(query,(error,result)=>{
            if(error){
                console.log("Error");
               res.redirect("/welcome");
            }
            else{
                console.log("Data Deleted Succesfully");
                res.redirect("/menu");
            }
        }) 
        })


        app.post("/read",encoded, (req, res) => {
            let name=req.body.name;
  let query="select  * from students where name ='"+name+"';";
            con.query(query, (error, dataa) => {
                if (error) {
                    throw error;
                }
                else {
                    res.render('Read', { ali: dataa})
                }
            })
        })

        app.get("/search",(req,res)=>{
            res.sendFile(__dirname+"/search.html");
        })

app.post("/update",encoded,(req,res)=>{
    //res.sendFile(__dirname+"/Registration.html");
    console.log("i am in post update");
     name=req.body.name;
    let query="select * from students where name = '"+name+"'";
    console.log(name);
    con.query(query,[name],(error,data)=>{
        if(error){
            console.log("Error");
          res.redirect("/welcome");
        }
        else{
            if(data.length>0){
                console.log("i am here");
                 console.log(data);

                res.render("update1",{data: data[0]});
            }
            else{
            console.log("No results found");
            res.redirect("/");
            }
        }
    })
    })


app.get("/add",(req,res)=>{
    res.sendFile(__dirname+"/add.html");
})

app.get("/update",(req,res)=>{
    console.log("i am in get update");
    res.sendFile(__dirname+"/update.html");
})

// app.post()

app.post("/add",encoded,(req,res)=>{
    //res.sendFile(__dirname+"/Registration.html");
    let name_=req.body.name_;
    let username=req.body.username;
    let email=req.body.email;
    let password=req.body.password;
    let phone=req.body.phone;
    let age=req.body.age;
    let qualification=req.body.qualification;

    console.log(email);

    //[username,email,password],
    con.query('INSERT INTO students(name,username,email,phonenumber,password,qualification,age) VALUES(?,?,?,?,?,?,?)',[name_,username,email,phone,password,qualification,age],(error,result)=>{
        if(error){
            console.log("Error");
           res.redirect("/welcome");
        }
        else{
            console.log("Data inserted");
            res.redirect("/menu");
        }
    }) 
    })
    
// app.get("/menu",()=>{
//     console.log("i am in");
//    res.sendFile(__dirname+"/menu.html");
// })




app.post("/login",encoded,(req,res)=>{

let name=req.body.username;
let pass=req.body.password;

// console.log(name);
// console.log(pass);

let query="select * from userdata where name = '"+name+"' and pass = '"+pass+"';"
console.log(query);
    con.query(query,function(error,result,fields){
        if(error){
console.log("Error");
        }
        
        else{
        if(result.length>0){
res.redirect("/menu");
        }
        else{
            console.log("Login Not Found");
            res.redirect("/registration");
        }

    }
    })

})


app.get("/welcome",(req,res)=>{
    res.sendFile(__dirname+"/welcome.html");
})

app.listen(4001,()=>{
    console.log("listening at port 4000");
})